"""Rendering for image agents (workflow.json `output: "image"`).

An image agent's model writes a brief — the prompt, a negative prompt and a caption —
and `render` turns it into an image with a Stability model on Bedrock, stores it in the
deployment's assets bucket, and returns where it is. The asset then carries the brief and
that location, so a reviewer at the gate sees the image and the words that made it.

Three things worth knowing:

* The image models run in ONE region (`imageModels.region` in vocabulary.json, us-west-2
  today). The brief is sent there whichever region the deployment is in; the image comes
  back and is stored in the deployment's own bucket, in its own region.
* Bedrock's text guardrails and AgentCore Evaluations do not look at images. The model
  has its own safety filter: a filtered image raises ImageFiltered, which fails the step
  with the model's reason rather than returning a blank.
* Images are addressed `runs/<session>/<agent>/<n>.<ext>`, so the BFF can check that the
  caller owns the run before it hands out a link, and deleting the stack deletes them.
"""

from __future__ import annotations

import base64
import json
import os
import time
from pathlib import Path

_VOCAB = json.loads((Path(__file__).resolve().parent.parent / "vocabulary.json").read_text())
MODELS: tuple[str, ...] = tuple(_VOCAB["imageModels"]["values"])
REGION: str = _VOCAB["imageModels"]["region"]
PRICES: dict = _VOCAB["imageModels"].get("pricePerImageUsd") or {}
ASPECT_RATIOS: tuple[str, ...] = tuple(_VOCAB["imageAspectRatios"]["values"])
FORMATS: tuple[str, ...] = tuple(_VOCAB["imageFormats"]["values"])

#: Set by both IaC paths when some agent has `output: "image"`.
ASSETS_BUCKET = os.getenv("ASSETS_BUCKET", "")
PROMPT_MAX = 10000


class ImageFiltered(RuntimeError):
    """The image model's safety filter withheld the image."""


_clients: dict = {}


def _client(service: str, region: str):
    if (service, region) not in _clients:
        import boto3
        _clients[(service, region)] = boto3.client(service, region_name=region)
    return _clients[(service, region)]


def settings(image: dict | None) -> dict:
    """An agent's `image` block with every default filled in."""
    image = dict(image or {})
    return {
        "model": str(image.get("model") or MODELS[0]),
        "aspectRatio": str(image.get("aspectRatio") or "1:1"),
        "outputFormat": str(image.get("outputFormat") or "png"),
        "seed": image.get("seed"),
        "negativePrompt": str(image.get("negativePrompt") or ""),
    }


def render(prompt: str, *, session_id: str, agent_id: str, image: dict | None = None,
           negative_prompt: str = "", bucket: str | None = None) -> dict:
    """Render one image and store it. Returns {imageKey, model, seed, format,
    aspectRatio, latencyMs, costUsd}."""
    bucket = bucket if bucket is not None else ASSETS_BUCKET
    if not bucket:
        raise RuntimeError("this deployment has no assets bucket (ASSETS_BUCKET), so it cannot "
                           "store images; redeploy after setting an agent's output to \"image\"")
    prompt = str(prompt or "").strip()
    if not prompt:
        raise ValueError("the image brief has no prompt")
    s = settings(image)
    negative = ", ".join(n for n in (s["negativePrompt"], str(negative_prompt or "").strip()) if n)
    body = {"prompt": prompt[:PROMPT_MAX], "mode": "text-to-image",
            "aspect_ratio": s["aspectRatio"], "output_format": s["outputFormat"]}
    if s["seed"] is not None:
        body["seed"] = int(s["seed"])
    if negative:
        body["negative_prompt"] = negative[:PROMPT_MAX]
    started = time.perf_counter()
    resp = _client("bedrock-runtime", REGION).invoke_model(
        modelId=s["model"], body=json.dumps(body), accept="application/json",
        contentType="application/json")
    out = json.loads(resp["body"].read())
    latency_ms = int((time.perf_counter() - started) * 1000)
    reasons = out.get("finish_reasons") or [None]
    if reasons[0]:
        raise ImageFiltered(f"{s['model']} withheld the image: {reasons[0]}")
    data = base64.b64decode((out.get("images") or [""])[0])
    if not data:
        raise RuntimeError(f"{s['model']} returned no image")
    ext = "jpg" if s["outputFormat"] == "jpeg" else "png"
    key = f"runs/{session_id}/{agent_id}/{int(time.time() * 1000)}.{ext}"
    _client("s3", os.getenv("AWS_REGION", "us-east-1")).put_object(
        Bucket=bucket, Key=key, Body=data,
        ContentType="image/jpeg" if ext == "jpg" else "image/png")
    return {"imageKey": key, "model": s["model"], "seed": (out.get("seeds") or [None])[0],
            "format": s["outputFormat"], "aspectRatio": s["aspectRatio"],
            "latencyMs": latency_ms, "costUsd": float(PRICES.get(s["model"], 0))}


# --- reading images back (workflow.json `vision`) --------------------------------------

#: Bedrock Converse takes an image of at most 3.75 MB, and up to 20 in one message.
IMAGE_MAX_BYTES = 3_750_000
VISION_MAX = 20
#: The default `vision.maxImages`.
VISION_DEFAULT = 4
_FORMATS = {"png": "png", "jpg": "jpeg", "jpeg": "jpeg", "gif": "gif", "webp": "webp"}


def keys_in(output) -> list[str]:
    """The image keys an agent's output lists: `images: [{"imageKey": ...}, ...]`, the
    shape an image agent returns — and any other agent (or tool) may return."""
    data = output
    if isinstance(output, str):
        try:
            data = json.loads(output)
        except ValueError:
            from app.common.assets import extract_json
            data = extract_json(output)
    if not isinstance(data, dict):
        return []
    return [str(i["imageKey"]) for i in (data.get("images") or [])
            if isinstance(i, dict) and isinstance(i.get("imageKey"), str) and i["imageKey"]]


def load_for(outputs: dict, sources: list[str], *, session_id: str,
             max_images: int = VISION_DEFAULT, bucket: str | None = None) -> list[dict]:
    """The images the agents in `sources` produced in THIS run, for a model to read:
    [{key, format, bytes}], in the order `sources` names them, at most `max_images`.

    Only keys under this run's own folder (runs/<session>/) are read, so an output that
    names another run's image — or anything else in the bucket — reads nothing."""
    bucket = bucket if bucket is not None else ASSETS_BUCKET
    own = f"runs/{session_id}/"
    keys = [k for src in sources for k in keys_in((outputs or {}).get(src))
            if k.startswith(own) and ".." not in k]
    keys = keys[:max(1, min(int(max_images or VISION_DEFAULT), VISION_MAX))]
    if not keys:
        return []
    if not bucket:
        raise RuntimeError("this deployment has no assets bucket (ASSETS_BUCKET), so there "
                           "are no images to read; an agent with `output: \"image\"` creates it")
    s3 = _client("s3", os.getenv("AWS_REGION", "us-east-1"))
    out = []
    for key in keys:
        fmt = _FORMATS.get(key.rsplit(".", 1)[-1].lower())
        if not fmt:
            raise ValueError(f"{key} is not an image format a model reads (png, jpeg, gif, webp)")
        data = s3.get_object(Bucket=bucket, Key=key)["Body"].read()
        if len(data) > IMAGE_MAX_BYTES:
            raise ValueError(f"{key} is {len(data) / 1e6:.1f} MB; a model reads images of at "
                             f"most {IMAGE_MAX_BYTES / 1e6:.2f} MB")
        out.append({"key": key, "format": fmt, "bytes": data})
    return out
